package com.example.flutter_ornek

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
