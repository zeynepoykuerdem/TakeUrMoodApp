import 'package:flutter/material.dart';

class Forgotpass extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Forgot Password')),
      body: const Center(
        child: Text(
          'This is a forgot password screen',
          style: TextStyle(fontSize: 24.0),
        ),
      ),
    );
  }
}