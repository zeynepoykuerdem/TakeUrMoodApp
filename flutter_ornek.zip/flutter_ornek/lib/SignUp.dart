import 'package:flutter/material.dart';

class SignUp extends StatefulWidget {
  State<SignUp> createState() => _SignUp();
}

class _SignUp extends State<SignUp> {
  bool _isVisible = true;
  bool _isPassEightChar = false;
  bool _hasPassOneNumber = false;
  bool _hasPassOneUppCase = false;
  bool _isValidName = false;

  onNameChanged(String Name) {
    final nameRegExp =
        new RegExp(r"^\s*([A-Za-z]{1,}([.,] |[-']| ))+[A-Za-z]+\.?\s*$");
    setState(() {
      _isValidName = false;
      if (nameRegExp.hasMatch(Name)) _isValidName = true;
    });
  }

  onPasswordChanged(String password) {
    final numRegex = RegExp(r'[0-9]');
    final regExp = RegExp('[A-Z]');

    setState(() {
      _isPassEightChar = false;
      if (password.length >= 8) _isPassEightChar = true;

      _hasPassOneNumber = false;
      if (numRegex.hasMatch(password)) _hasPassOneNumber = true;

      _hasPassOneUppCase =
          false; // regular expression controls the string input if it has any [A-Z] element , if it has a match then the boolean expression turns to true and the color of the box is green.
      if (regExp.hasMatch(password)) _hasPassOneUppCase = true;
    });
  }

  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.pink,
        title: Text(
          'Create Your Account',
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: Container(
          padding: EdgeInsets.symmetric(horizontal: 40, vertical: 40),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

              Text(
                "Set a password",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              SizedBox(
                height: 10,
              ),
              Text(
                "Please create a secure password including the following criteria below.",
                style: TextStyle(
                    fontSize: 16, height: 1.5, color: Colors.grey.shade600),
              ),
              SizedBox(
                height: 30,
              ),
              TextField(
                onChanged: (password) => onPasswordChanged(password),
                obscureText: _isVisible,
                decoration: InputDecoration(
                  labelText: 'Password',
                  // this button is used to change the password visibility
                  suffixIcon: IconButton(
                    onPressed: () {
                      setState(() {
                        _isVisible = !_isVisible;
                      });
                    },
                    icon: _isVisible
                        ? Icon(
                            Icons.visibility,
                            color: Colors.black,
                          )
                        : Icon(
                            Icons.visibility_off,
                            color: Colors.grey,
                          ),
                  ),
                  border: OutlineInputBorder(
                      // passwordu yerleştiridğimiz kutunun şekli

                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(color: Colors.black)),
                  focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(color: Colors.black)),
                  hintText: "Password",
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                ),
              ),
              SizedBox(
                height: 30,
              ),
              Row(
                children: [
                  AnimatedContainer(
                    duration: Duration(milliseconds: 500),
                    width: 20,
                    height: 20,
                    decoration: BoxDecoration(
                        color: _isPassEightChar
                            ? Colors.green
                            : Colors.transparent,
                        border: _isPassEightChar
                            ? Border.all(color: Colors.transparent)
                            : Border.all(color: Colors.grey.shade400),
                        borderRadius: BorderRadius.circular(50)),
                    child: Center(
                      child: Icon(
                        Icons.check,
                        color: Colors.white,
                        size: 15,
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Text("Contains at least 8 characters")
                ],
              ),
              SizedBox(
                height: 10,
              ),
              Row(
                children: [
                  AnimatedContainer(
                    duration: Duration(milliseconds: 500),
                    width: 20,
                    height: 20,
                    decoration: BoxDecoration(
                        color: _hasPassOneNumber
                            ? Colors.green
                            : Colors.transparent,
                        border: _hasPassOneNumber
                            ? Border.all(color: Colors.transparent)
                            : Border.all(color: Colors.grey.shade400),
                        borderRadius: BorderRadius.circular(50)),
                    child: Center(
                      child: Icon(
                        Icons.check,
                        color: Colors.white,
                        size: 15,
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Text("Contains at least 1 number")
                ],
              ),
              SizedBox(
                height: 10,
              ),
              Row(
                children: [
                  AnimatedContainer(
                    duration: Duration(milliseconds: 500),
                    width: 20,
                    height: 20,
                    decoration: BoxDecoration(
                        color: _hasPassOneUppCase
                            ? Colors.green
                            : Colors.transparent,
                        border: _hasPassOneUppCase
                            ? Border.all(color: Colors.transparent)
                            : Border.all(color: Colors.grey.shade400),
                        borderRadius: BorderRadius.circular(50)),
                    child: Center(
                      child: Icon(
                        Icons.check,
                        color: Colors.white,
                        size: 15,
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Text("Contains at least 1 uppercase letter")
                ],
              ),

            ],
          )),
    );
  }
}
